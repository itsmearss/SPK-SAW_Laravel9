

<?php $__env->startSection('container'); ?>
     <div class="header">
        <div class="box-header">
            <div class="box">
                <div class="header-container">
                    <div class="title mt-5">
                        <h1 class="animate__animated animate__fadeInUp"> Find The Perfect <br> House 
                            <br> For You.
                        </h1>
                        <p class="animate__animated animate__fadeInUp animate__delay-1s">It's great to be home!</p>
                    </div>
                    
                    <div class="info animate__animated animate__fadeInUp animate__delay-1s">
                        <div class="box">
                            <h1><?php echo e($count_house->count()); ?> <i class="fa-solid fa-arrow-up"></i></h1>
                            <p>Property in website</p>
                        </div>
                        <div class="box">
                            <h1><?php echo e($count_article->count()); ?> <i class="fa-solid fa-arrow-up"></i></h1>
                            <p>Our Articles</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box">
                <img src="img/hero.jpg" alt="pexel.com">
            </div>
        </div>
    </div>
    

    
    <section id="premium">
        <div class="container-fluid py-5 mt-2 px-5">
            <h2 class="text-center fw-bold" data-aos="fade-up" data-aos-duration="1000">Premium Listings</h2>
            <p class="text-center" data-aos="fade-up" data-aos-duration="1000">Premium listings are listings from trusted agents</p>
            <div class="row mt-5">
                <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card mb-3" data-aos="fade-up" data-aos-duration="1000">
                        <p class="position-absolute px-3 py-2 mt-2 ms-2" style="background-color: rgba(0, 0, 0, 0.7); border-radius: 3px;"><a href="" class="text-decoration-none text-white"><?php echo e(($house->status == "1") ? 'Dijual' : 'Disewa'); ?></a></p>
                        <?php if($house->main_image): ?>
                        <div style="overflow:hidden" class="mt-3 mb-3">
                             <img src="<?php echo e(asset('storage/'.$house->main_image)); ?>" alt="<?php echo e($house->nama_rumah); ?>" style="height: 250px; width: 100%" class="img-fluid">
                        </div>
                        <?php else: ?>
                        <img src="https://source.unsplash.com/500x500?property" class="card-img-top" alt="..." width="100%" height="230px">
                        <?php endif; ?>
                        <div class="card-body">
                          <h6 class="card-title fw-bold"><a href="/houses/<?php echo e($house->slug); ?>" class="text-decoration-none text-dark"><?php echo e($house->nama_rumah); ?></a></h6>
                          
                          <p class="card-text text-secondary"><?php echo e($house->kota); ?>, <?php echo e($house->provinsi); ?></p>
                          <div class="d-flex flex-row justify-content-center text-center text-secondary">
                            <div class="p-1 mx-3">
                                <i class="fa-solid fa-bed"></i>
                                <p><?php echo e($house->kamar_tidur); ?> KT</p>
                            </div>
                            <div class="p-1 mx-3">
                                <i class="fa-solid fa-shower"></i>
                                <p><?php echo e($house->kamar_mandi); ?> KM</p>
                            </div>
                            <div class="p-1 mx-3">
                                <i class="fa-sharp fa-solid fa-house-chimney"></i>
                                <p><?php echo e($house->luas_bangunan); ?> m2</p>
                            </div>
                            <div class="p-1 mx-3">
                                <i class="fa-solid fa-ruler-combined"></i>
                                <p><?php echo e($house->luas_tanah); ?> m2</p>
                            </div>
                          </div>
                        </div>
                        <div class="card-footer py-3">
                          <div class="d-flex flex-row justify-content-between">
                            <div class="p-1">
                                <h6 class="fw-bold mb-0">IDR <?php echo e($house->harga); ?> M</h6>
                              </div>
                              <div class="p-1">
                                <i class="fa-sharp fa-regular fa-bookmark"></i>
                              </div>
                          </div>
                        </div>
                      </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    

    
    <div class="bg-fixed">
        <h1>ARS PROPERTY</h1>
    </div>
    

    
    <section id="why">
        <div class="container-fluid py-5 px-5">
            <h2 class="text-center fw-bold" data-aos="fade-up" data-aos-duration="1000">Why Choose Us</h2>
            <p class="text-center" data-aos="fade-up" data-aos-duration="1000">We provide the most complete and reliable property advertising services</p>
            <div class="row mt-5">
                <div class="col-sm-4">
                    <div class="card" data-aos="fade-up" data-aos-duration="1000">
                        <div class="mx-auto mt-5 mb-4 text-center">
                            <img src="icon/award.gif" alt="" width="30%">
                        </div>
                        <div class="card-body text-center">
                          <h5 class="card-title fw-bold">Certified</h5>
                          <p class="card-text text-secondary">has a certificate and is registered to guarantee the quality of the house</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="card" data-aos="fade-up" data-aos-duration="1000">
                        <div class="mx-auto mt-5 mb-4 text-center">
                            <img src="icon/social-care.gif" alt="" width="30%">
                        </div>
                        <div class="card-body text-center">
                          <h5 class="card-title fw-bold">Various Properties Available</h5>
                          <p class="card-text text-secondary">Providing various property options for investors and buyers/tenants in finding the right property.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="card" data-aos="fade-up" data-aos-duration="1000">
                        <div class="mx-auto mt-5 mb-4 text-center">
                            <img src="icon/idea.gif" alt="" width="30%">
                        </div>
                        <div class="card-body text-center">
                          <h5 class="card-title fw-bold">Much Easier Searcher</h5>
                          <p class="card-text text-secondary">System updates have improved listing search performance, making it much easier and faster.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    

    
    <section id="arc">
        <div class="container-fluid py-5 px-5">
            <h2 class="text-center fw-bold" data-aos="fade-up" data-aos-duration="1000">Our Most Popular Articles</h2>
            <p class="text-center" data-aos="fade-up" data-aos-duration="1000">Collection of all property articles</p>
            <div class="row mt-5">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3">
                    <div class="card mb-3" data-aos="fade-up" data-aos-duration="1000">
                        <p class="position-absolute px-3 py-2 mt-2 ms-2" style="background-color: rgba(13, 110, 253, 0.7); border-radius: 3px;"><a href="/artikel?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none text-white"><?php echo e($post->category->name); ?></a></p>
                        <img src="https://source.unsplash.com/500x400?<?php echo e($post->category->name); ?>" class="card-img-top" alt="<?php echo e($post->category->name); ?>">
                        <div class="card-body">
                            <p class="card-text text-secondary mb-2"><i class="fa-sharp fa-regular fa-calendar"></i>  <?php echo e($post->created_at->diffForHumans()); ?></p>
                            <h6 class="card-title"><a href="/artikel/<?php echo e($post->slug); ?>" class="text-decoration-none text-dark fw-bold"><?php echo e($post->title); ?></a></h6>
                            <p class="card-text text-secondary mb-3"><?php echo e($post->excerpt); ?></p>
                            <a href="/artikel/<?php echo e($post->slug); ?>" style="color: rgb(13, 110, 253);" class="fw-bold">READ MORE</a>
                        </div>
                      </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annur\OneDrive - Microsoft365\Code\Laravel\dss\resources\views/home.blade.php ENDPATH**/ ?>