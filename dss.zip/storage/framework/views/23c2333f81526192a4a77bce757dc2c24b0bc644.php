<?php $__env->startSection('container'); ?>
    <section id="premium">
        <div class="container-fluid py-5 mt-3 px-5">
            <h2 class="text-center fw-bolder">Decision Support Systems</h2>
            <p class="text-center">Help choose the best housing for you.</p>
            <form action="/spk/alternatives" method="POST">
                <?php echo csrf_field(); ?>
                <h4 class="fw-bolder">Add Alternatives</h4>
                <div class="flex-row d-flex justify-content-between">
                    <div class="mb-3 col-lg-8 d-flex">
                        <select class="form-select rounded-1" name="house">
                          <?php $__currentLoopData = $houses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $house): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($house); ?>" selected>
                                <?php if($house->status == 1): ?>
                                    Dijual
                                <?php else: ?>
                                    Disewa
                                <?php endif; ?>
                                 - <?php echo e($house->nama_rumah); ?> - Price: <?php echo e($house->harga); ?>M</option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3 d-flex">
                        <button type="submit" class="btn btn-dark rounded-0" style="background-color: black">ADD</button>
                    </div>
                </div>
            </form>
            <?php if(session()->has('success')): ?>
                <div class="alert alert-success col-lg-8" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
           <div class="table-responsive">
            <table class="table table-striped">
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>ID Alt</th>
                    <th>Nama Rumah</th>
                    <th>Price</th>
                    <th>LB</th>
                    <th>LT</th>
                    <th>KT</th>
                    <th>KM</th>
                    <th>DL</th>
                    
                    <th class="text-center">View</th>
                    <th class="text-center">Delete</th>
                </tr>
                <?php $__currentLoopData = $alternatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($alternative->id_rumah); ?></td>
                    <td><?php echo e($alternative->alternative); ?></td>
                    <td><?php echo e($alternative->nama_rumah); ?></td>
                    <td><?php echo e($alternative->harga); ?></td>
                    <td><?php echo e($alternative->luas_bangunan); ?></td>
                    <td><?php echo e($alternative->luas_tanah); ?></td>
                    <td><?php echo e($alternative->kamar_tidur); ?></td>
                    <td><?php echo e($alternative->kamar_mandi); ?></td>
                    <td><?php echo e($alternative->daya_listrik); ?></td>
                    <td class="text-center"><a href="/houses/<?php echo e($alternative->slug); ?>" class="badge bg-info text-center"><i class="bi bi-eye"></i></a></td>
                    
                    <td class="text-center">
                        <form action="/spk/alternatives/<?php echo e($alternative->id); ?>" method="POST" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="badge bg-danger border-0" onclick="return confirm('Are you sure?')"><i class="bi bi-x-circle"></i></button>
                          </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
           </div>
            <div class="d-flex justify-content-between">
                <a href="/" class="btn btn-danger col-lg-3 rounded-0 fw-bold">CANCEL</a>
                <a href="/spk/saw/kriteria" class="btn btn-dark col-lg-3 rounded-0 fw-bold" style="background-color: black">LAKUKAN SAW</a>
                <a href="/spk/matriks" class="btn btn-dark col-lg-3 rounded-0 fw-bold" style="background-color: black">LAKUKAN AHP</a>
            </div>
            <div class="mt-5">
                <h5 class="fw-bold">Keterangan: </h5>
                <table>
                    <tr>
                        <td style="width: 20px">1.</td>
                        <td style="width: 50px">Price</td>
                        <td style="width: 20px">=</td>
                        <td>Harga</td>
                    </tr>
                    <tr>
                        <td style="width: 20px">2.</td>
                        <td style="width: 50px">LB</td>
                        <td style="width: 20px">=</td>
                        <td>Luas Bangunan</td>
                    </tr>
                    <tr>
                        <td style="width: 20px">3.</td>
                        <td style="width: 50px">LT</td>
                        <td style="width: 20px">=</td>
                        <td>Luas Tanah</td>
                    </tr>
                    <tr>
                        <td style="width: 20px">4.</td>
                        <td style="width: 50px">KT</td>
                        <td style="width: 20px">=</td>
                        <td>Kamar Tidur</td>
                    </tr>
                    <tr>
                        <td style="width: 20px">5.</td>
                        <td style="width: 50px">KM</td>
                        <td style="width: 20px">=</td>
                        <td>Kamar Mandi</td>
                    </tr>
                    <tr>
                        <td style="width: 20px">6.</td>
                        <td style="width: 50px">DL</td>
                        <td style="width: 20px">=</td>
                        <td>Daya Listrik</td>
                    </tr>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annur\OneDrive - Microsoft365\Code\Laravel\dss\resources\views/spk/spk.blade.php ENDPATH**/ ?>