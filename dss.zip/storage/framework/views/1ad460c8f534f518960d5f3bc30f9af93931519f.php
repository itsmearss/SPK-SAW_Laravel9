

<?php $__env->startSection('container'); ?>
    <section id="premium">
        <div class="container-fluid py-5 mt-3">
            <h2 class="text-center fw-bolder">Contact Us</h2>
            <p class="text-center mb-5">Please complete the following fields to send us an inquiry.</p>
            <?php if(session()->has('success')): ?>
            <div class="alert alert-success col-lg-4 mx-auto" role="alert">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
                <div class="container mt-2">
                    <div class="row" style="box-shadow: 1px 1px 8px black">
                    <div class="col-sm-4 bg-dark text-white p-5">
                        <h4 class="fw-semibold mb-3 text-white">Let's get in touch</h4>
                        <small class="mb-4 d-block">We're open for any suggestion or just to have a chat</small>
                        <table>
                            <tr class="mb-4">
                                <td style="width: 50px"  class="text-center"><p class="fs-4"><i class="bi bi-geo-alt"></i></p></td>
                                <td><p>Address: Selapura City</p></td>
                            </tr>
                            <tr>
                                <td style="width: 50px"  class="text-center"><p class="fs-4"><i class="bi bi-telephone"></i></p></td>
                                <td><p>Phone: +62 856 4224 0515</p></td>
                            </tr>
                            <tr>
                                <td style="width: 50px"  class="text-center"><p class="fs-4"><i class="bi bi-envelope"></i></p></td>
                                <td><p>Email: annurriyadhus17@gmail.com</p></td>
                            </tr>
                            <tr>
                                <td style="width: 50px"  class="text-center"><p class="fs-4"><i class="bi bi-globe"></i></p></td>
                                <td><p>Website: arsproperty.com</p></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-sm-8 p-5">
                        <h4 class="fw-semibold mb-3">Get in touch</h4>
                        <form action="/contact/store" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="col-lg-6" style="">
                                    <label for="full_name" class="form-label">Full Name</label>
                                    <input type="text" class="form-control rounded-1 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="full_name" name="full_name" placeholder="Full Name" required value="<?php echo e(old('name')); ?>">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                          <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-lg-6">
                                    <label for="email" class="form-label">Email Address</label>
                                    <input type="text" class="form-control rounded-1 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                          <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="subject" class="form-label">Subject</label>
                                <input type="text" class="form-control rounded-1 <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="subject" name="subject" placeholder="Subject" required value="<?php echo e(old('subject')); ?>">
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                      <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3">
                                <label for="message" class="form-label">Message</label>
                                <textarea class="form-control rounded-1 <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="message" name="message" rows="3" placeholder="Message" required placeholder="Message"></textarea>
                            </div>
                            <button class="btn btn-dark rounded-1" type="submit">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annur\OneDrive - Microsoft365\Code\Laravel\dss\resources\views/contact.blade.php ENDPATH**/ ?>