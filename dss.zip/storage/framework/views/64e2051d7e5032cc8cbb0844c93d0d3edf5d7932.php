

<?php $__env->startSection('container'); ?>
    <div class="container py-4">
        <div class="row justify-content-center">
            <div class="col-md-8">
                    <h2><?php echo e($post->title); ?></h2>
                    <p>By: <a href="/artikel?author=<?php echo e($post->author->username); ?>" class="text-decoration-none"><?php echo e($post->author->nama); ?></a> in <a href="/artikel?category=<?php echo e($post->category->slug); ?>" class="text-decoration-none"><?php echo e($post->category->name); ?></a></p>
                    <?php if($post->image): ?>
                        <div style="max-height: 350px; overflow:hidden">
                             <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                        </div>
                    <?php else: ?>
                        <img src="https://source.unsplash.com/1200x400?<?php echo e($post->category->name); ?>" alt="<?php echo e($post->category->name); ?>" class="img-fluid">
                    <?php endif; ?>
                    <article class="my-3">
                        <?php echo $post->body; ?>

                    </article>
                <a href="/artikel" class="text-decoration-none">Back to artikel</a>   
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\annur\OneDrive - Microsoft365\Code\Laravel\dss\resources\views/post.blade.php ENDPATH**/ ?>